import './globals.css';
export const metadata={title:'JARVIS / Personal intelligence',description:'Your voice, your workspace, your Mac. A personal assistant with visible approvals.'};
export default function Layout({children}){return <html lang="en"><body>{children}</body></html>;}
