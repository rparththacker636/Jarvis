import {localRequest,body,verify,companion,fail} from '../../../lib/server.js';
export const runtime='nodejs';
export async function POST(req){try{localRequest(req);const p=await body(req,220000);const action=verify(p);const result=await companion('/action',{method:'POST',body:JSON.stringify({payload:p.payload,signature:p.signature})});return Response.json({action:action.action,result});}catch(e){return fail(e);}}
