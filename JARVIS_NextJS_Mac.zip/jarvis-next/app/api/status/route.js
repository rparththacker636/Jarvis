import {aiConfig} from '../../../lib/config.js';
import {localRequest,companion,fail} from '../../../lib/server.js';
export const runtime='nodejs';
export async function GET(req){try{localRequest(req);let connected=false,platform=null;try{const data=await companion('/health');connected=true;platform=data.platform;}catch{}const {provider,model,configured}=aiConfig();return Response.json({provider,model,configured,companion:connected,platform,paired:!!process.env.JARVIS_TOKEN});}catch(e){return fail(e);}}
