import base64
import hashlib
import hmac
import importlib.util
import json
import plistlib
from pathlib import Path
import tempfile
import time
import unittest
import uuid
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('companion', Path(__file__).resolve().parents[1] / 'companion/server.py')
s = importlib.util.module_from_spec(spec)
spec.loader.exec_module(s)

class CompanionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        s.WORKSPACE = Path(self.temp.name)
        s.TOKEN = 'test-token-only' * 4
        s.SEEN.clear()

    def tearDown(self):
        self.temp.cleanup()

    def signed(self, expires=None):
        item = {'id': str(uuid.uuid4()), 'action': 'list_files', 'args': {}, 'expires': expires or time.time() * 1000 + 30000}
        payload = base64.urlsafe_b64encode(json.dumps(item).encode()).decode().rstrip('=')
        return {'payload': payload, 'signature': hmac.new(s.TOKEN.encode(), payload.encode(), hashlib.sha256).hexdigest()}

    def test_approvals_are_single_use(self):
        data = self.signed()
        self.assertEqual(s.verified(data)['action'], 'list_files')
        with self.assertRaises(ValueError): s.verified(data)

    def test_expired_and_modified_approvals(self):
        with self.assertRaises(ValueError): s.verified(self.signed(1))
        data = self.signed()
        data['signature'] = '0' * 64
        with self.assertRaises(ValueError): s.verified(data)

    def test_create_read_list_and_no_overwrite(self):
        s.execute('create_file', {'path': 'project/hello.txt', 'content': 'Hello, Parth! नमस्कार'})
        self.assertIn('नमस्कार', s.execute('read_file', {'path': 'project/hello.txt'})['content'])
        self.assertEqual(s.execute('list_files', {})['files'], ['project/hello.txt'])
        with self.assertRaises(FileExistsError): s.execute('create_file', {'path': 'project/hello.txt', 'content': 'overwrite'})
        self.assertIn('Hello', s.execute('read_file', {'path': 'project/hello.txt'})['content'])

    def test_paths_and_symlinks_are_confined(self):
        for path in ['../outside', '/tmp/outside', '.env', 'a/.hidden', 'a//b']:
            with self.assertRaises(ValueError): s.valid_path(path)
        (s.WORKSPACE / 'escape').symlink_to('/tmp', target_is_directory=True)
        with self.assertRaises(ValueError): s.valid_path('escape/file')

    def test_no_arbitrary_commands(self):
        with self.assertRaises(ValueError): s.execute('shell', {'command': 'whoami'})
        with self.assertRaises(ValueError): s.execute('open_app', {'app': 'Safari;echo injected'})
        with self.assertRaises(ValueError): s.execute('set_volume', {'level': True})

    def test_mac_argv_are_fixed(self):
        with patch.object(s.platform, 'system', return_value='Darwin'), patch.object(s, 'resolve_app', return_value={'name':'Calculator','path':'/System/Applications/Calculator.app'}), patch.object(s.subprocess, 'run') as run:
            run.return_value.returncode = 0
            s.execute('open_app', {'app': 'Calculator'})
            self.assertEqual(run.call_args.args[0], ['/usr/bin/open', '-a', '/System/Applications/Calculator.app'])
            self.assertFalse(run.call_args.kwargs['shell'])
            s.execute('set_volume', {'level': 35})
            self.assertEqual(run.call_args.args[0], ['/usr/bin/osascript', '-e', 'set volume output volume 35'])

    def make_app(self, relative, name, identifier):
        path = s.WORKSPACE / relative
        (path / 'Contents').mkdir(parents=True)
        with (path / 'Contents/Info.plist').open('wb') as f:
            plistlib.dump({'CFBundlePackageType':'APPL', 'CFBundleName':name, 'CFBundleIdentifier':identifier}, f)
        return s.app_info(path)

    def test_any_app_names_ids_aliases_and_explicit_paths(self):
        spotify = self.make_app('Spotify.app', 'Spotify', 'com.spotify.client')
        chrome = self.make_app('Google Chrome.app', 'Google Chrome', 'com.google.Chrome')
        with patch.object(s.platform, 'system', return_value='Darwin'), patch.object(s, 'discover_apps', return_value=[spotify, chrome]):
            self.assertEqual(s.resolve_app('spotify')['path'], spotify['path'])
            self.assertEqual(s.resolve_app('com.spotify.client')['path'], spotify['path'])
            self.assertEqual(s.resolve_app('Chrome')['path'], chrome['path'])
            self.assertEqual(s.resolve_app('Spotify.app')['path'], spotify['path'])
            self.assertEqual(s.resolve_app(spotify['path'])['path'], spotify['path'])
            with self.assertRaises(ValueError): s.resolve_app('Spotify; echo injected')
            with self.assertRaises(ValueError): s.resolve_app('/bin/sh')

    def test_ambiguous_names_require_exact_path(self):
        apps = [self.make_app('a/Editor.app','Editor','com.a.editor'),self.make_app('b/Editor.app','Editor','com.b.editor')]
        with patch.object(s.platform, 'system', return_value='Darwin'), patch.object(s, 'discover_apps', return_value=apps):
            with self.assertRaisesRegex(ValueError, 'Multiple apps match'): s.resolve_app('Editor')
            self.assertEqual(s.resolve_app(apps[1]['path'])['path'], apps[1]['path'])

    def test_discovery_reads_bundles_and_skips_nested_helpers(self):
        self.make_app('Tools/My App.app','My App','com.example.app')
        self.make_app('Tools/My App.app/Contents/Helper.app','Helper','com.example.helper')
        s.APP_CACHE.update(at=0, items=[])
        with patch.object(s.platform, 'system', return_value='Darwin'), patch.object(s, 'APP_ROOTS', [s.WORKSPACE]), patch.object(s.subprocess, 'run', side_effect=OSError('Spotlight unavailable')):
            apps=s.discover_apps(refresh=True)
            self.assertEqual([a['name'] for a in apps], ['My App'])

    def test_websites_reject_non_web_schemes_and_credentials(self):
        for url in ['javascript:alert(1)', 'file:///tmp/a', 'data:text/html,test', 'https://user:pass@example.com', 'https://example.com\\evil', 'https://example.com\n', 'https://example.com:99999']:
            with self.assertRaises(ValueError): s.website_url(url)
        self.assertEqual(s.website_url('https://example.com/a?q=1&b=2'), 'https://example.com/a?q=1&b=2')

    def test_website_open_uses_one_literal_argument(self):
        url='https://example.com/?q=$(touch%20oops)&x=1'
        with patch.object(s.platform, 'system', return_value='Darwin'), patch.object(s.subprocess, 'run') as run:
            run.return_value.returncode=0
            result=s.execute('open_website', {'url':url})
            self.assertEqual(run.call_args.args[0], ['/usr/bin/open',url])
            self.assertFalse(run.call_args.kwargs['shell'])
            self.assertEqual(result['url'],url)

if __name__ == '__main__': unittest.main()
