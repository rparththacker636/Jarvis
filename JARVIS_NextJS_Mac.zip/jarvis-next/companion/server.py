"""Local-only JARVIS companion. Python standard library; no shell execution."""
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
import base64
import hashlib
import hmac
import json
import os
import platform
import plistlib
import unicodedata
import re
import ipaddress
from urllib.parse import urlsplit
import subprocess
import time
import uuid

PROJECT = Path(__file__).resolve().parent.parent

def load_env():
    path = PROJECT / '.env.local'
    if path.exists():
        for line in path.read_text().splitlines():
            if line.strip() and not line.lstrip().startswith('#') and '=' in line:
                key, value = line.split('=', 1)
                os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))

load_env()
TOKEN = os.environ.get('JARVIS_TOKEN', '')
WORKSPACE = Path(os.environ.get('JARVIS_WORKSPACE', str(Path.home() / 'JARVIS Workspace'))).expanduser().resolve()
APP_ROOTS = [Path('/Applications'), Path.home() / 'Applications', Path('/System/Applications'), Path('/System/Library/CoreServices')]
APP_CACHE = {'at': 0, 'items': []}
SEEN = {}

def app_key(value):
    value = unicodedata.normalize('NFKC', value).strip().casefold()
    return value[:-4] if value.endswith('.app') else value

def app_info(path):
    path = Path(path).expanduser().resolve()
    if path.suffix.casefold() != '.app' or not path.is_dir():
        raise ValueError('Choose an existing .app application bundle.')
    try:
        with (path / 'Contents' / 'Info.plist').open('rb') as f:
            info = plistlib.load(f)
    except (OSError, ValueError, plistlib.InvalidFileException):
        raise ValueError('The application bundle has no readable Info.plist.')
    if not isinstance(info, dict) or (info.get('CFBundlePackageType') != 'APPL' and not info.get('CFBundleExecutable')):
        raise ValueError('The selected bundle is not an application.')
    aliases = [path.stem] + [info[k] for k in ['CFBundleDisplayName', 'CFBundleName', 'CFBundleIdentifier'] if isinstance(info.get(k), str)]
    return {'name': aliases[1] if len(aliases) > 1 else path.stem, 'path': str(path), 'bundle_id': info.get('CFBundleIdentifier', ''), 'aliases': aliases}

def discover_apps(refresh=False):
    if platform.system() != 'Darwin':
        raise ValueError('Application discovery requires macOS.')
    if not refresh and APP_CACHE['at'] > 0 and time.monotonic() - APP_CACHE['at'] < 30:
        return APP_CACHE['items']
    candidates = set()
    for root in APP_ROOTS:
        for base, dirs, _ in os.walk(root, followlinks=False):
            keep = []
            for name in dirs:
                path = Path(base) / name
                if name.lower().endswith('.app'):
                    candidates.add(str(path))
                elif not name.startswith('.') and not path.is_symlink():
                    keep.append(name)
            dirs[:] = keep
    # Spotlight finds indexed applications installed in non-standard locations.
    try:
        found = subprocess.run(['/usr/bin/mdfind', "kMDItemContentType == 'com.apple.application-bundle'"], shell=False, capture_output=True, text=True, timeout=5)
        if found.returncode == 0:
            candidates.update(found.stdout.splitlines())
    except (OSError, subprocess.SubprocessError):
        pass
    items = {}
    for path in sorted(candidates):
        try:
            item = app_info(path)
            items[item['path']] = item
        except (ValueError, OSError, RuntimeError):
            continue
    APP_CACHE.update(at=time.monotonic(), items=sorted(items.values(), key=lambda x: x['name'].casefold()))
    return APP_CACHE['items']

def resolve_app(query):
    if not isinstance(query, str) or not query.strip() or len(query) > 1024 or any(ord(c) < 32 for c in query) or query.startswith('-'):
        raise ValueError('Enter an application name, bundle identifier or .app path.')
    if platform.system() != 'Darwin':
        raise ValueError('Opening applications requires macOS.')
    if query.startswith(('/', '~/')):
        return app_info(query)
    query = app_key(query)
    aliases = {'chrome': 'google chrome', 'vscode': 'visual studio code', 'vs code': 'visual studio code', 'settings': 'system settings', 'system preferences': 'system settings'}
    items = discover_apps()
    matches = [a for a in items if query in [app_key(x) for x in a['aliases']]]
    if not matches and query in aliases:
        query = aliases[query]
        matches = [a for a in items if query in [app_key(x) for x in a['aliases']]]
    if len(matches) == 1:
        return matches[0]
    if len(matches) > 1:
        raise ValueError('Multiple apps match. Use "open " followed by one exact path: ' + ' | '.join(a['path'] for a in matches[:5]))
    suggestions = [a['name'] for a in items if any(query in app_key(x) for x in a['aliases'])][:5]
    raise ValueError('App not found. Try "list apps" or an absolute .app path.' + (' Matches: ' + ', '.join(suggestions) if suggestions else ''))

def valid_path(value):
    if not isinstance(value, str) or not 0 < len(value) <= 240 or value.startswith('/') or '\\' in value or any(ord(c) < 32 for c in value):
        raise ValueError('Use a visible relative workspace path.')
    parts = value.split('/')
    if any(not p or p.startswith('.') for p in parts):
        raise ValueError('Hidden files and parent traversal are blocked.')
    current = WORKSPACE
    for part in parts:
        current = current / part
        if current.is_symlink():
            raise ValueError('Symbolic links are blocked.')
    resolved = current.resolve()
    if not resolved.is_relative_to(WORKSPACE):
        raise ValueError('Path is outside the workspace.')
    return resolved

def website_url(value):
    if not isinstance(value, str) or not value or len(value) > 4096 or any(c.isspace() or ord(c) < 32 or ord(c) == 127 for c in value) or '\\' in value:
        raise ValueError('Invalid website address.')
    url = urlsplit(value)
    if url.scheme.lower() not in ('http', 'https') or not url.netloc or not url.hostname or url.username is not None or url.password is not None:
        raise ValueError('Only HTTP/HTTPS websites without embedded credentials are allowed.')
    host = url.hostname.rstrip('.')
    if ':' in host:
        ipaddress.IPv6Address(host)
    elif not re.fullmatch(r'[a-zA-Z0-9.-]+', host) or any(not label or len(label) > 63 or label.startswith('-') or label.endswith('-') for label in host.split('.')):
        raise ValueError('Invalid website hostname.')
    if url.port is not None and not 1 <= url.port <= 65535:
        raise ValueError('Invalid website port.')
    return value

def validate(action, args):
    fields = {'open_website': {'url'}, 'open_app': {'app'}, 'list_apps': set(), 'set_volume': {'level'}, 'screenshot': set(), 'list_files': set(), 'read_file': {'path'}, 'create_file': {'path', 'content'}}
    if not isinstance(action, str) or action not in fields or not isinstance(args, dict) or set(args) != fields[action]:
        raise ValueError('Unsupported action or arguments.')
    if action == 'open_website':
        website_url(args['url'])
    if action == 'open_app' and (not isinstance(args['app'], str) or not args['app'].strip() or len(args['app']) > 1024 or any(ord(c) < 32 for c in args['app']) or args['app'].startswith('-')):
        raise ValueError('Invalid application name or path.')
    if action == 'set_volume' and (type(args['level']) is not int or not 0 <= args['level'] <= 100):
        raise ValueError('Volume must be an integer from 0 to 100.')
    if 'path' in args:
        valid_path(args['path'])
    if action == 'create_file' and (not isinstance(args['content'], str) or len(args['content']) > 30000):
        raise ValueError('File content is too large.')

def verified(data):
    if not isinstance(data, dict):
        raise ValueError('Invalid approval.')
    payload, signature = data.get('payload'), data.get('signature')
    if not isinstance(payload, str) or len(payload) > 180000 or not isinstance(signature, str):
        raise ValueError('Invalid approval.')
    expected = hmac.new(TOKEN.encode(), payload.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, signature):
        raise ValueError('Invalid approval signature.')
    item = json.loads(base64.urlsafe_b64decode(payload + '=' * (-len(payload) % 4)))
    now = time.time() * 1000
    if type(item.get('expires')) not in (int, float) or not now < item['expires'] <= now + 301000:
        raise ValueError('Approval expired.')
    uuid.UUID(item.get('id', ''))
    validate(item.get('action'), item.get('args'))
    for key, expiry in list(SEEN.items()):
        if expiry < now:
            del SEEN[key]
    if item['id'] in SEEN:
        raise ValueError('This approval has already been used. Ask again to repeat it.')
    SEEN[item['id']] = item['expires']
    return item

def mac_run(command):
    if platform.system() != 'Darwin':
        raise ValueError('This Mac action requires macOS. Workspace actions work on this platform.')
    result = subprocess.run(command, shell=False, capture_output=True, text=True, timeout=15)
    if result.returncode:
        raise ValueError('macOS could not complete this action. Check that the app is installed and the required macOS permissions are enabled.')

def execute(action, args):
    validate(action, args)
    if action == 'open_website':
        url = website_url(args['url'])
        mac_run(['/usr/bin/open', url])
        return {'message': f"macOS accepted the request to open {urlsplit(url).hostname} in your default browser.", 'url': url}
    if action == 'open_app':
        app = resolve_app(args['app'])
        mac_run(['/usr/bin/open', '-a', app['path']])
        return {'message': f"macOS accepted the request to open {app['name']}.", 'path': app['path']}
    if action == 'list_apps':
        apps = discover_apps(refresh=True)
        return {'apps': [{k: a[k] for k in ['name', 'path', 'bundle_id']} for a in apps], 'count': len(apps)}
    if action == 'set_volume':
        mac_run(['/usr/bin/osascript', '-e', f"set volume output volume {args['level']}"])
        return {'message': f"Output volume set to {args['level']}%."}
    if action == 'screenshot':
        name = 'screenshot-' + str(uuid.uuid4())[:8] + '.png'
        path = valid_path(name)
        mac_run(['/usr/sbin/screencapture', '-x', str(path)])
        if not path.exists() or not path.stat().st_size:
            raise ValueError('Screenshot was not saved. Allow Screen Recording for your terminal in macOS settings.')
        return {'message': 'Screenshot saved locally. The image was not sent to the AI.', 'path': name}
    if action == 'list_files':
        files = []
        for base, dirs, names in os.walk(WORKSPACE, followlinks=False):
            relative = Path(base).relative_to(WORKSPACE)
            dirs[:] = [d for d in dirs if not d.startswith('.') and not (Path(base) / d).is_symlink() and len(relative.parts) < 4]
            for name in sorted(names):
                path = Path(base) / name
                if not name.startswith('.') and not path.is_symlink():
                    files.append(str(path.relative_to(WORKSPACE)))
                    if len(files) >= 200:
                        return {'files': files, 'limit': 'First 200 files; at most 4 nested directories.'}
        return {'files': files, 'message': f'{len(files)} files in JARVIS Workspace.'}
    path = valid_path(args['path'])
    if action == 'read_file':
        if not path.is_file() or path.stat().st_size > 60000:
            raise ValueError('Choose an existing UTF-8 text file smaller than 60 KB.')
        content = path.read_text(encoding='utf-8')
        if len(content) > 30000:
            raise ValueError('Text file exceeds the 30,000-character limit.')
        return {'path': args['path'], 'content': content}
    if action == 'create_file':
        path.parent.mkdir(parents=True, exist_ok=True)
        path = valid_path(args['path'])
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0), 0o600)
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            f.write(args['content'])
        return {'message': 'New file created.', 'path': args['path']}
    raise ValueError('Unsupported action.')

class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass  # Avoid logging chat, file content, or credentials.

    def reply(self, code, value):
        data = json.dumps(value).encode()
        self.send_response(code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(data)

    def authorized(self):
        if self.headers.get('Host') != '127.0.0.1:8765' or self.headers.get('Origin'):
            self.reply(403, {'error': 'Local server requests only.'})
            return False
        auth = self.headers.get('Authorization', '')
        if not hmac.compare_digest(auth, 'Bearer ' + TOKEN):
            self.reply(401, {'error': 'Companion authentication failed.'})
            return False
        return True

    def do_GET(self):
        if self.authorized():
            if self.path == '/health':
                self.reply(200, {'ok': True, 'platform': platform.system()})
            else:
                self.reply(404, {'error': 'Not found.'})

    def do_POST(self):
        if not self.authorized():
            return
        if self.path not in ['/action', '/resolve-app']:
            return self.reply(404, {'error': 'Not found.'})
        try:
            length = int(self.headers.get('Content-Length', '0'))
            if not 0 < length <= 200000:
                raise ValueError('Invalid request size.')
            data = json.loads(self.rfile.read(length))
            if self.path == '/resolve-app':
                return self.reply(200, resolve_app(data.get('query')))
            item = verified(data)
            result = execute(item['action'], item['args'])
            self.reply(200, result)
        except (ValueError, TypeError, KeyError, OSError, subprocess.SubprocessError) as e:
            self.reply(400, {'error': str(e)[:250]})

if __name__ == '__main__':
    if len(TOKEN) < 32:
        raise SystemExit('Run npm run setup first.')
    WORKSPACE.mkdir(parents=True, exist_ok=True, mode=0o700)
    server = HTTPServer(('127.0.0.1', 8765), Handler)
    server.timeout = 10
    print('JARVIS companion ready at 127.0.0.1:8765. Ctrl+C to stop.')
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        server.server_close()
