# JARVIS — Personal Intelligence

A new, local-first Next.js assistant for Parth's Mac. Includes a polished responsive interface, AI chat, push-to-talk dictation, spoken replies, saved conversations, editable memory, local tasks, an activity log, and a Python Mac companion with configurable immediate opening and action approvals.

This is a working first version with defined capabilities, not an unrestricted autonomous computer operator. It does not run arbitrary shell commands, send emails, access every file, or control arbitrary websites. Nothing in the app should claim a Mac action succeeded until the companion returns its result.

## 1. Start on your Mac

Requirements: Node.js 20.9+ and Python 3.10+. A current Node LTS release is appropriate. Chrome is a useful first choice for browser dictation, subject to OS/browser support and microphone permission.

Extract the ZIP. Open Terminal in the `jarvis-next` folder. If unsure, type `cd `, drag that folder into Terminal, and press Enter.

```bash
npm ci
npm run setup
```

Setup creates `.env.local` with a random private pairing token and creates `~/JARVIS Workspace`. It does not overwrite an existing configuration. The companion uses Python's standard library, so no pip installation is required.

Open two Terminal windows in the project folder.

Terminal 1:

```bash
npm run companion
```

Terminal 2:

```bash
npm run dev
```

Open http://localhost:3000. Use Ctrl+C in each Terminal to stop its server. Both services bind to your own computer. Do not expose either port to the internet. This local Mac edition is not a Vercel deployment: a remote server cannot control the apps on your Mac.

Without any AI key, try:

- `open Calculator`
- `open Safari`
- `volume 30`
- `take a screenshot`
- `list files`
- `read file notes.txt` (place the file in JARVIS Workspace first)

App and website opening run immediately by default. Other actions produce an approval card: review it, then click **Approve & run**. Disable **Settings → Mac companion → Open apps and websites immediately** to require approval for opening requests too. Approvals expire after five minutes and are single-use. Restored chat approvals are disabled after reload.

## 2. Connect an AI provider

### Gemini (default in this build)

Get your own Gemini API key from https://aistudio.google.com/apikey. Edit `.env.local` locally:

```dotenv
AI_PROVIDER=gemini
AI_MODEL=gemini-3.6-flash
GEMINI_API_KEY=your_gemini_key_here
```

Keep JARVIS_TOKEN unchanged. Restart Next.js. No OpenAI key is required for Gemini. You can choose another available Gemini model that supports generateContent and function calling. This adapter uses the documented REST generateContent endpoint. Account access, quotas, and model availability are controlled by Google.

Upgrading from the earlier ZIP: replace the project source files while preserving your existing `.env.local`, then add the Gemini settings above. If using a fresh extracted folder, run `npm ci` and `npm run setup` first. Stop the old servers and start the companion and Next.js from the updated folder. No live key is included in this download.

Gemini supports chat and approval-based Mac/workspace action proposals. The Web toggle displays an explanatory notice: Google Search grounding is not implemented in this version. Browser voice input/output continue to work independently of the selected chat provider.

### OpenAI (optional alternative)

Open `.env.local` in a text editor (on macOS you can run `open -e .env.local`). Add your API key and a model you can access:

```dotenv
AI_PROVIDER=openai
AI_MODEL=gpt-4.1-mini
OPENAI_API_KEY=your_api_key_here
```

Keep the generated `JARVIS_TOKEN` unchanged. Restart the Next.js server after editing. If you change the token or workspace path, restart both servers. The configured model above is an example, not a claim that it is the most capable model available; you can select another Responses API model with function calling. The Web toggle additionally requires model support and access for the hosted web search tool.

API use may incur charges. The UI only reports configuration presence, not account access or credit availability. A real chat request verifies those. Keys stay on the server and never appear in frontend settings. Never share `.env.local` or commit it to Git.

### Ollama (optional local AI)

Install and start Ollama using its official instructions: https://docs.ollama.com . Download a model appropriate for your Mac's available memory. Use `ollama list` to find the exact installed model name.

```dotenv
AI_PROVIDER=ollama
AI_MODEL=your-installed-model-name
OPENAI_API_KEY=
```

This app connects only to `http://127.0.0.1:11434/api/chat`. The model must support tool calling for AI-generated action proposals. No local model is included in the ZIP. Local model speed and quality depend on hardware/model size. Hosted web search is implemented only for OpenAI in this version. Explicit direct commands remain usable without an AI provider.

## 3. What this version can do

| Feature | Behavior |
| --- | --- |
| Chat | Text answers, code generation, explanations and planning through Gemini, OpenAI or Ollama |
| Conversation history | Up to 20 conversations in this browser; export as JSON |
| Context | Recent messages are sent to the provider within a bounded request size |
| Voice input | Click microphone, speak, review transcription, then send |
| Voice output | Spoken replies on by default; voice picker, speed/pitch/volume controls, replay and stop |
| Stop | Cancels pending chat and browser voice; does not undo a Mac action already submitted |
| Memory | User-edited context, automatically saved locally and included with AI requests |
| Web research | Optional OpenAI web search with clickable citation annotations |
| Mac apps | Any installed macOS .app, resolved by name, bundle ID or exact .app path |
| Websites | Open HTTP/HTTPS destinations in the default Mac browser |
| Audio | Set system output volume from 0–100 |
| Screenshot | Save a local PNG in the workspace; no screenshot upload or AI image understanding |
| Files | List files, read UTF-8 text, create new files only inside the workspace |
| Tasks | Local checklist and in-app reminders while the page is open and the computer is awake |
| Action history | Successful, failed and declined actions, with timestamps |

Example AI requests after connection:

- “Explain JavaScript promises using an easy example.”
- “Make a realistic 30-minute Python practice plan.”
- “Create a file called ideas.txt with five beginner project ideas.”
- “Read file notes.txt and help me summarize it.”
- “Help me build a simple weather interface in Next.js.”

For multi-step work, approve the proposed action, read its result, then click **Explain result / continue**. The app offers one action at a time. App and website openings may run immediately based on your setting; their results appear in chat and Activity.

## Open any installed Mac app

The fixed app list has been removed. Try `open Spotify`, `launch WhatsApp`, `open Terminal`, `open Chrome`, or `open Microsoft Word`. Each application must already be installed.

`list apps` shows discovered names and absolute paths. The companion scans /Applications, ~/Applications, /System/Applications and CoreServices, and supplements the list with Spotlight results. The discovery cache lasts 30 seconds; `list apps` forces a refresh. Apps outside the normal folders can be found through Spotlight or opened using their absolute .app path.

Names and bundle IDs are matched case-insensitively. Common aliases include Chrome, VS Code and Settings. If multiple applications match, JARVIS asks for an exact path. For an unindexed app, use `open /absolute/path/My App.app`. The companion validates the application bundle, signs the exact resolved path, checks the bundle again on execution, and passes it as a single argument to macOS `open -a` without a shell or extra launch arguments. Missing or damaged applications produce a visible error.

This opens applications; it does not grant JARVIS unrestricted control inside their windows. macOS may still block an incompatible or quarantined app. macOS launch behavior has not been tested on your device; discovery/resolution and command arguments are covered by automated tests with synthetic app bundles.

## Open websites without approval

Website opening is now built in, including direct commands that work without an AI key:

- `open YouTube`
- `open Google`
- `open github.com`
- `visit https://example.com/docs?q=hello`
- `open website WhatsApp`

The local companion opens the destination in your Mac’s default browser. It reports when macOS accepts the request; it does not claim the website has finished loading. Website opening works independently of the Web research toggle.

**Open apps and websites immediately** is enabled by default in Settings → Mac companion. Requests to open an app or website execute without an approval card. You can disable this setting to restore approval for opening requests. Other actions retain their existing approval flow. Immediate openings still use authenticated, signed, single-use commands and appear in Activity. The setting applies to new requests; Stop cannot undo a launch already sent to macOS.

Common names resolve to known destinations. Domains gain `https://` automatically. Full paths, query strings and fragments are preserved. Only HTTP and HTTPS are accepted; executable URL schemes, embedded credentials, and malformed addresses are rejected. URLs are passed as one argument to macOS `open`, without a shell. The assistant does not sign in, fill forms or click inside the website.

To resolve an app/website name collision, say `open app YouTube` for an installed app, or `open website Spotify` for its web version. `open Spotify` still means the installed app. Unknown website names need a domain or full address.

Upgrade by replacing the project files while keeping `.env.local`, then restart both the Next.js server and Python companion. New settings default to immediate opening on first use; later choices are saved in this browser. Gemini configuration and voice preferences remain intact.

## JARVIS voice

Open **Settings → JARVIS voice** and click **Test voice**. This test does not need an AI connection. New replies are spoken automatically by default in this version, and completed actions can announce their result. The first upgrade enables voice; later on/off preferences are remembered. The composer’s Voice toggle mutes automatic speech. Individual assistant messages have a **Read aloud** button that works even when automatic speech is off.

Choose a voice from the available browser/OS voices and adjust speed, pitch, and volume. Automatic selection prefers Daniel or another available British English voice, then falls back to another English or system voice. This is a system voice, not an actor voice clone. Voices may vary by browser and installed macOS voice packs. No additional voice API key is needed; Gemini still generates the reply text.

Long replies are spoken in short sequential chunks rather than silently truncated. Code blocks are replaced by “Code is shown on screen.” The Stop button, beginning dictation, sending another prompt, or disabling voice interrupts speech and discards the remaining chunks. The header shows when speech is queued or playing. If the browser blocks playback, click Test voice or Read aloud. Voice volume is separate from system output volume.

Voice settings are stored in this browser. A voice labelled “device voice” is reported as local by the browser; other voices may depend on a network service. Test actual audio on your Mac. Automated tests validate chunk sequencing, selection, parameter bounds, cancellation, and error messages using mocked speech APIs; they do not measure audible voice quality.

## 4. Files, permissions and privacy

- Default workspace: `~/JARVIS Workspace`. Place files there manually. You may explicitly set `JARVIS_WORKSPACE` to another dedicated absolute directory in `.env.local`; restart both services.
- Existing files are never overwritten. Hidden paths, parent traversal, symlink paths and absolute file requests are rejected. File creation is capped at 30,000 characters; text reads at 60 KB / 30,000 characters. Listings show at most 200 files and four directory levels.
- Browser requests go through same-origin Next.js routes. The local companion requires a private bearer token and a signed, expiring approval. It runs fixed argument arrays with `shell=False`.
- macOS may ask permission for Automation or Screen Recording. For screenshots, grant Screen Recording to the application hosting the companion (for example Terminal), then restart it if required.
- Browser voice recognition may send microphone audio to your browser provider. It is push-to-talk, not a private offline speech model or a wake-word listener. Spoken output uses the browser/OS speech implementation.
- Chats, memory, tasks and activity are stored in this browser's localStorage. They are not encrypted by the app and are not synced across devices. Export before clearing browser data.
- Chat content and saved memory are sent to the selected AI provider when you send a message. After approving a file read, its text appears in chat and will be included in subsequent AI requests, subject to context limits. The approval card explains this. Screenshots remain local images and are not sent.
- OpenAI calls use `store:false`; this is not a promise about all provider retention policies. See the provider's current policies for its handling of API data.

## 5. Project structure

```text
app/
  page.jsx              App Router page
  layout.jsx            Metadata and base layout
  globals.css           Responsive interface styling
  api/chat/route.js     Direct-command routing and AI responses
  api/action/route.js   Approval verification and companion proxy
  api/status/route.js   Configuration and companion health
components/Jarvis.jsx   Chat, voice, memory, tasks, approvals and settings
lib/actions.js          Tool schemas, validation and direct commands
lib/ai.js               AI provider routing
lib/gemini.js           Gemini REST adapter and proposal parsing
lib/config.js           Shared provider configuration checks
lib/speech.js           Voice selection, speech chunks and cancellable playback
lib/server.js           Local origin checks and signed approvals
companion/server.py     Local Python Mac and workspace actions
scripts/setup.py        Private token and workspace setup
tests/                  Node and Python tests
.env.example            Configuration template (no secrets)
```

The UI is a React client component. Keys and API calls remain in Next.js server routes. Python only exposes the allowlisted companion actions. No database or paid UI dependencies are required.

## 6. Build and test

```bash
npm test
npm run build
npm start
```

Run `npm run companion` separately for production mode too.

Verification in the build environment: 27 Node tests and 11 Python tests passed. These cover action validation, path confinement, approval signatures/replay prevention, provider-response parsing with mocked responses, actual create/read/list behavior inside a temporary directory, overwrite prevention, and fixed macOS command arguments. The production build passed.

Limitations of verification: no live provider credentials or local Ollama model were available, and this build environment is not your Mac. Real AI requests, microphone/speech output, macOS actions and screen-recording permissions require testing on your machine. Browser visual QA was unavailable.

## Troubleshooting

- **Companion offline:** run setup, start the companion from this folder, and click Refresh connections in Settings. Check that both servers use the same `.env.local`.
- **Port 3000 occupied:** stop the other local Next.js app or use the localhost URL printed by Next.js. This is relevant if GestureSynth is still running.
- **Port 8765 occupied:** stop the old companion before starting another.
- **AI not connected:** fill in the key and model, then restart Next.js. A ChatGPT browser login is not passed to the API.
- **Quota / model error:** check API access and the selected model. The UI displays the provider error.
- **Ollama error:** start Ollama, verify `ollama list`, and choose an installed model supporting tools.
- **No voice input:** allow microphone access, use a supported browser on localhost, or type instead.
- **No speech output:** open Settings → JARVIS voice, click Test voice, check voice volume and Mac output volume, and try another voice.
- **Approval expired / already used:** ask for the action again; review the new approval.
- **Screenshot failure:** review macOS Screen Recording permission for the terminal running Python.
- **App not found:** install the app or try “list apps” and use the exact displayed name or .app path.
- **File exists:** choose a new filename. This version does not overwrite existing files.

## Possible next upgrades

Native Mac menu-bar launcher, streaming conversation, local speech recognition, task-specific code runners with isolation, authenticated calendar/email connectors, richer file previews, and stronger long-term memory. Each should be added as a tested capability with its own permissions and clear action reporting.

Official technical references:
- https://ai.google.dev/gemini-api/docs/generate-content/function-calling
- https://ai.google.dev/gemini-api/docs/models
- https://nextjs.org/docs/app/getting-started/installation
- https://developers.openai.com/api/docs/guides/function-calling
- https://developers.openai.com/api/docs/guides/tools-web-search
- https://github.com/ollama/ollama/blob/main/docs/api.md
