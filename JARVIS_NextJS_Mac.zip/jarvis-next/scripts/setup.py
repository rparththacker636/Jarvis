from pathlib import Path
import secrets
import os
root = Path(__file__).resolve().parent.parent
path = root / '.env.local'
if not path.exists():
    path.write_text((root / '.env.example').read_text().replace('GENERATED_BY_SETUP', secrets.token_hex(32)))
    os.chmod(path, 0o600)
    print('Created .env.local with a private companion token. Add your AI settings there; never share this file.')
else:
    print('.env.local already exists. Your settings were kept.')
workspace = Path.home() / 'JARVIS Workspace'
workspace.mkdir(exist_ok=True, mode=0o700)
print('Workspace ready. Run npm run companion in one terminal and npm run dev in another.')
